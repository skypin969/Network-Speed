#!/system/bin/sh
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
i=0
while [ $i -lt 12 ]; do
  cur=$(cmd phone get-allowed-network-types-for-users -s 0 2>/dev/null | tr -d "\r")
  case "$cur" in
    *"LTE|LTE_CA|NR"*) ;;
    *) cmd phone set-allowed-network-types-for-users -s 0 10000001000000000000 ;;
  esac
  sleep 10
  i=$((i+1))
done
